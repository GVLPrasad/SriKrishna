import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo123',
  templateUrl: './demo123.component.html',
  styleUrls: ['./demo123.component.scss']
})
export class Demo123Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
