import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-back-ground',
  templateUrl: './back-ground.component.html',
  styleUrls: ['./back-ground.component.scss']
})
export class BackGroundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
