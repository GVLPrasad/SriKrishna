import { MobileMaskPipe } from './mobile-mask.pipe';

describe('MobileMaskPipe', () => {
  it('create an instance', () => {
    const pipe = new MobileMaskPipe();
    expect(pipe).toBeTruthy();
  });
});
