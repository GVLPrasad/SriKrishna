import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-he',
  templateUrl: './he.component.html',
  styleUrls: ['./he.component.scss']
})
export class HEComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
